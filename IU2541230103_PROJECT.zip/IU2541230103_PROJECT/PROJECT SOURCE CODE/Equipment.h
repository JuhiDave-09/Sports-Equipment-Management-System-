#ifndef EQUIPMENT_H
#define EQUIPMENT_H
#include "Record.h"

class Equipment : public Record {
private:
    std::string type;     // e.g. Cricket, Football, Badminton
    std::string status;   // Available / Issued / Under Repair / Lost
public:
    Equipment();
    Equipment(int id, const std::string& name, const std::string& type, const std::string& status);
    ~Equipment();

    const std::string& getType() const;
    const std::string& getStatus() const;
    void setType(const std::string& t);
    void updateStatus(const std::string& s);
    bool isAvailable() const;

    void display() const;
    std::string serialize() const;
    void deserialize(const std::string& line);
    std::string typeName() const;
};
#endif
