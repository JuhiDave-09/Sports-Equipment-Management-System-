#ifndef FILEMANAGER_H
#define FILEMANAGER_H
#include <string>

class SportsCenter;   // forward declaration

// Writes / reads the four data files in the Data/ folder
class FileManager {
private:
    std::string dir;
    std::string path(const std::string& file) const;
    void ensureDir() const;
public:
    FileManager();
    explicit FileManager(const std::string& dir);
    ~FileManager();

    void save(SportsCenter& sc);
    bool load(SportsCenter& sc);   // returns true if at least one data file was found
};
#endif
