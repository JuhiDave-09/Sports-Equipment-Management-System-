#include "Utils.h"
#include <iostream>
#include <cctype>
#include <cstdlib>

std::string trim(const std::string& s) {
    size_t a = 0, b = s.size();
    while (a < b && isspace((unsigned char)s[a])) a++;
    while (b > a && isspace((unsigned char)s[b - 1])) b--;
    return s.substr(a, b - a);
}
std::string toLower(const std::string& s) {
    std::string r = s;
    for (size_t i = 0; i < r.size(); i++) r[i] = (char)tolower((unsigned char)r[i]);
    return r;
}
bool containsNoCase(const std::string& text, const std::string& key) {
    return toLower(text).find(toLower(key)) != std::string::npos;
}

std::string readLine(const std::string& prompt) {
    std::cout << prompt;
    std::string line;
    if (!std::getline(std::cin, line)) throw InputClosedException();
    return trim(line);
}

int readInt(const std::string& prompt, int lo, int hi) {
    while (true) {
        std::string s = readLine(prompt);
        bool ok = !s.empty() && s.size() < 9;
        for (size_t i = 0; ok && i < s.size(); i++) if (!isdigit((unsigned char)s[i])) ok = false;
        if (ok) {
            int v = atoi(s.c_str());
            if (v >= lo && v <= hi) return v;
        }
        std::cout << "  Error: enter a number between " << lo << " and " << hi << ".\n";
    }
}

void validateText(const std::string& s, const std::string& field) {
    if (s.empty()) throw ValidationException(field + " cannot be empty.");
    if (s.size() > 40) throw ValidationException(field + " is too long (max 40 characters).");
    if (s.find('|') != std::string::npos) throw ValidationException(field + " cannot contain the '|' character.");
}
void validateName(const std::string& s) {
    validateText(s, "Name");
    for (size_t i = 0; i < s.size(); i++) {
        unsigned char c = (unsigned char)s[i];
        if (!(isalpha(c) || c == ' ' || c == '.' || c == '\'' || c == '-'))
            throw ValidationException("Name may contain only letters, spaces, '.', '-' and apostrophes.");
    }
}
void validatePhone(const std::string& s) {
    if (s.size() != 10) throw ValidationException("Phone must be exactly 10 digits.");
    for (size_t i = 0; i < s.size(); i++)
        if (!isdigit((unsigned char)s[i])) throw ValidationException("Phone must be exactly 10 digits.");
}
void validateDate(const std::string& s) {
    if (s.size() != 10 || s[2] != '/' || s[5] != '/')
        throw ValidationException("Date must be in DD/MM/YYYY format.");
    for (size_t i = 0; i < s.size(); i++) {
        if (i == 2 || i == 5) continue;
        if (!isdigit((unsigned char)s[i])) throw ValidationException("Date must be in DD/MM/YYYY format.");
    }
    int d = atoi(s.substr(0, 2).c_str());
    int m = atoi(s.substr(3, 2).c_str());
    int y = atoi(s.substr(6, 4).c_str());
    if (y < 2000 || y > 2100) throw ValidationException("Year must be between 2000 and 2100.");
    if (m < 1 || m > 12) throw ValidationException("Invalid date (month must be 01-12).");
    int days[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    bool leap = (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0);
    if (leap) days[1] = 29;
    if (d < 1 || d > days[m - 1]) throw ValidationException("Invalid date (day out of range for month).");
}
int dateToNumber(const std::string& d) {
    return atoi(d.substr(6, 4).c_str()) * 10000 + atoi(d.substr(3, 2).c_str()) * 100 + atoi(d.substr(0, 2).c_str());
}

// Each reader re-prompts until the input is valid (exception handling + validation)
std::string readName(const std::string& prompt) {
    while (true) {
        try { std::string s = readLine(prompt); validateName(s); return s; }
        catch (const ValidationException& e) { std::cout << "  Error: " << e.what() << "\n"; }
    }
}
std::string readText(const std::string& prompt, const std::string& field) {
    while (true) {
        try { std::string s = readLine(prompt); validateText(s, field); return s; }
        catch (const ValidationException& e) { std::cout << "  Error: " << e.what() << "\n"; }
    }
}
std::string readPhone(const std::string& prompt) {
    while (true) {
        try { std::string s = readLine(prompt); validatePhone(s); return s; }
        catch (const ValidationException& e) { std::cout << "  Error: " << e.what() << "\n"; }
    }
}
std::string readDate(const std::string& prompt) {
    while (true) {
        try { std::string s = readLine(prompt); validateDate(s); return s; }
        catch (const ValidationException& e) { std::cout << "  Error: " << e.what() << "\n"; }
    }
}
