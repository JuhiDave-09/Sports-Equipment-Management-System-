#ifndef MEMBER_H
#define MEMBER_H
#include "Record.h"

class Member : public Record {
private:
    std::string phone;
public:
    Member();
    Member(int id, const std::string& name, const std::string& phone);
    ~Member();

    const std::string& getPhone() const;
    void setPhone(const std::string& p);

    void display() const;
    std::string serialize() const;
    void deserialize(const std::string& line);
    std::string typeName() const;
};
#endif
