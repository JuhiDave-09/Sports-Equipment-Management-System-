// Sports Equipment Management - C++ Console OOP Project
// main.cpp only creates the system object and starts the menu.
#include <string>
#include "SportsCenter.h"

int main(int argc, char* argv[]) {
    std::string dataDir = (argc > 1) ? argv[1] : "Data";
    SportsCenter center(dataDir);
    center.run();
    return 0;
}
