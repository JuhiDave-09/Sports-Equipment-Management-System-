#include "Record.h"

Record::Record() : id(0), name("") {}
Record::Record(int i, const std::string& n) : id(i), name(n) {}
Record::~Record() {}
int Record::getId() const { return id; }
const std::string& Record::getName() const { return name; }
void Record::setId(int newId) { id = newId; }
void Record::setName(const std::string& newName) { name = newName; }

int splitFields(const std::string& line, std::string out[], int maxFields) {
    int n = 0;
    std::string cur;
    for (size_t i = 0; i <= line.size(); i++) {
        if (i == line.size() || line[i] == '|') {
            if (n < maxFields) out[n] = cur;
            n++;
            cur.clear();
        } else cur += line[i];
    }
    return n;
}
