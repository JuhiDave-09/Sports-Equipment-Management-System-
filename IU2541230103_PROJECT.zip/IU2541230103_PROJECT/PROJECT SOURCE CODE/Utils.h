#ifndef UTILS_H
#define UTILS_H
#include <string>
#include <stdexcept>

// ---------- Exception hierarchy ----------
class AppException : public std::runtime_error {
public:
    explicit AppException(const std::string& m) : std::runtime_error(m) {}
};
class ValidationException : public AppException {
public:
    explicit ValidationException(const std::string& m) : AppException(m) {}
};
class InputClosedException : public AppException {
public:
    InputClosedException() : AppException("Input closed.") {}
};

// ---------- Input helpers ----------
std::string readLine(const std::string& prompt);
int readInt(const std::string& prompt, int lo, int hi);
std::string toLower(const std::string& s);
std::string trim(const std::string& s);
bool containsNoCase(const std::string& text, const std::string& key);

// ---------- Validation (throw ValidationException) ----------
void validateName(const std::string& s);
void validateText(const std::string& s, const std::string& field);
void validatePhone(const std::string& s);
void validateDate(const std::string& s);
int dateToNumber(const std::string& d);   // DD/MM/YYYY -> YYYYMMDD

std::string readName(const std::string& prompt);
std::string readText(const std::string& prompt, const std::string& field);
std::string readPhone(const std::string& prompt);
std::string readDate(const std::string& prompt);
#endif
