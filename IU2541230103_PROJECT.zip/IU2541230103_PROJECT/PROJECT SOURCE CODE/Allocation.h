#ifndef ALLOCATION_H
#define ALLOCATION_H
#include "Record.h"

// One issue of an equipment item to a member (result of the "issue" transaction)
class Allocation : public Record {
private:
    int equipmentId;
    int memberId;
    std::string date;     // DD/MM/YYYY
    bool returned;        // false while the item is still with the member
public:
    Allocation();
    Allocation(int id, int equipmentId, int memberId, const std::string& date);
    ~Allocation();

    void allocate(int eqId, int memId, const std::string& d);
    int getEquipmentId() const;
    int getMemberId() const;
    const std::string& getDate() const;
    bool isReturned() const;
    void setReturned(bool r);

    void display() const;
    std::string serialize() const;
    void deserialize(const std::string& line);
    std::string typeName() const;
};
#endif
