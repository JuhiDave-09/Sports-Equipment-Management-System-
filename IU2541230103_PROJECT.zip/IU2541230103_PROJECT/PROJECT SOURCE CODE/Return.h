#ifndef RETURN_H
#define RETURN_H
#include "Record.h"

// One return of an issued item (result of the "return" transaction)
class Return : public Record {
private:
    int allocationId;
    std::string date;       // DD/MM/YYYY
    std::string condition;  // Good / Damaged / Lost
public:
    Return();
    Return(int id, int allocationId, const std::string& date, const std::string& condition);
    ~Return();

    void processReturn(int allocId, const std::string& d, const std::string& cond);
    int getAllocationId() const;
    const std::string& getDate() const;
    const std::string& getCondition() const;

    void display() const;
    std::string serialize() const;
    void deserialize(const std::string& line);
    std::string typeName() const;
};
#endif
