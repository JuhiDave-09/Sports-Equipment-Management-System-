#include "Return.h"
#include "Utils.h"
#include <iomanip>
#include <cstdlib>

Return::Return() : Record(), allocationId(0), date(""), condition("Good") {}
Return::Return(int i, int a, const std::string& d, const std::string& c)
    : Record(i, "Return"), allocationId(a), date(d), condition(c) {}
Return::~Return() {}

void Return::processReturn(int allocId, const std::string& d, const std::string& cond) {
    allocationId = allocId; date = d; condition = cond; name = "Return";
}
int Return::getAllocationId() const { return allocationId; }
const std::string& Return::getDate() const { return date; }
const std::string& Return::getCondition() const { return condition; }

void Return::display() const {
    std::cout << "  Return " << std::setw(3) << id << " | Allocation ID: " << std::setw(3) << allocationId
              << " | Returned on: " << date << " | Condition: " << condition << "\n";
}
std::string Return::serialize() const {
    return std::to_string(id) + "|" + std::to_string(allocationId) + "|" + date + "|" + condition;
}
void Return::deserialize(const std::string& line) {
    std::string f[4];
    if (splitFields(line, f, 4) != 4) throw AppException("Corrupt return record: " + line);
    id = atoi(f[0].c_str());
    allocationId = atoi(f[1].c_str());
    date = f[2]; condition = f[3];
    name = "Return";
    if (id <= 0 || allocationId <= 0) throw AppException("Corrupt return record: " + line);
    validateDate(date);
}
std::string Return::typeName() const { return "Return"; }
