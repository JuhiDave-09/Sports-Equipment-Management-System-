#ifndef STORE_H
#define STORE_H
#include <stdexcept>

// Generic dynamic array. Memory is allocated with new[] and released with delete[].
// The number of records is unknown in advance, so the array grows (doubles) when full.
template <typename T>
class Store {
private:
    T* items;
    int count;
    int capacity;

    Store(const Store&);              // copying is disabled (owns raw memory)
    Store& operator=(const Store&);

    void grow() {
        int newCap = capacity * 2;
        T* bigger = new T[newCap];
        for (int i = 0; i < count; i++) bigger[i] = items[i];
        delete[] items;
        items = bigger;
        capacity = newCap;
    }
public:
    explicit Store(int cap = 4) : items(new T[cap]), count(0), capacity(cap) {}
    ~Store() { delete[] items; }

    int size() const { return count; }
    void add(const T& item) {
        if (count == capacity) grow();
        items[count++] = item;
    }
    T& at(int index) {
        if (index < 0 || index >= count) throw std::out_of_range("Store index out of range");
        return items[index];
    }
    const T& at(int index) const {
        if (index < 0 || index >= count) throw std::out_of_range("Store index out of range");
        return items[index];
    }
    int indexOfId(int id) const {
        for (int i = 0; i < count; i++) if (items[i].getId() == id) return i;
        return -1;
    }
    void removeAt(int index) {
        if (index < 0 || index >= count) throw std::out_of_range("Store index out of range");
        for (int i = index; i < count - 1; i++) items[i] = items[i + 1];
        count--;
    }
    int nextId() const {
        int m = 0;
        for (int i = 0; i < count; i++) if (items[i].getId() > m) m = items[i].getId();
        return m + 1;
    }
    void clear() { count = 0; }
};
#endif
