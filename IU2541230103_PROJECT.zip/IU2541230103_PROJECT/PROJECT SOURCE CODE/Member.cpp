#include "Member.h"
#include "Utils.h"
#include <iomanip>
#include <cstdlib>

Member::Member() : Record(), phone("") {}
Member::Member(int i, const std::string& n, const std::string& p) : Record(i, n), phone(p) {}
Member::~Member() {}

const std::string& Member::getPhone() const { return phone; }
void Member::setPhone(const std::string& p) { phone = p; }

void Member::display() const {
    std::cout << "  ID: " << std::setw(3) << id << " | " << std::left << std::setw(22) << name
              << " | " << phone << std::right << "\n";
}
std::string Member::serialize() const { return std::to_string(id) + "|" + name + "|" + phone; }
void Member::deserialize(const std::string& line) {
    std::string f[3];
    if (splitFields(line, f, 3) != 3) throw AppException("Corrupt member record: " + line);
    id = atoi(f[0].c_str());
    name = f[1]; phone = f[2];
    if (id <= 0 || name.empty()) throw AppException("Corrupt member record: " + line);
}
std::string Member::typeName() const { return "Member"; }
