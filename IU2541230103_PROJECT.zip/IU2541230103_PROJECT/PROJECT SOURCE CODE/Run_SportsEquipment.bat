@echo off
cd /d "%~dp0"
if not exist SportsEquipment.exe (
    echo SportsEquipment.exe not found. Building it first...
    g++ -std=c++11 main.cpp SportsCenter.cpp FileManager.cpp Record.cpp Equipment.cpp Member.cpp Allocation.cpp Return.cpp Utils.cpp -o SportsEquipment.exe
)
SportsEquipment.exe
pause
