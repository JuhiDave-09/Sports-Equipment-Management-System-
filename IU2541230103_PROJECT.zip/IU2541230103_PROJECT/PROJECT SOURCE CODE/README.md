# Sports Equipment Management (C++ console OOP project)

**Student:** Dave Juhi  |  **Enrollment No.:** IU2541230103  |  **Project code:** CPP66  |  **Subject:** C++ Guided Project (Semester 3)

A menu-driven console application that manages sports equipment and members, issues and returns
equipment with validation, tracks the condition of returned items and stores everything permanently in text files.

## Features
- 9-option menu (Add, Display, Search, Update, Delete, Main Transaction, Report, Save/Load, Exit)
- Main transaction: **Issue** equipment to a member and **Return** it (Good / Damaged / Lost)
- Rules: an item cannot be issued twice, a member can hold at most 3 items, return date cannot be before the issue date
- Input validation (name, 10-digit phone, DD/MM/YYYY dates) and exception handling
- Automatic load at start, automatic save at exit (also manual Save / Load)

## OOP concepts
Classes and objects, encapsulation, default + parameterized constructors, destructors, inheritance
(`Record` -> `Equipment`, `Member`, `Allocation`, `Return`), runtime polymorphism (pure virtual
`display/serialize/deserialize`), dynamic memory (`Store<T>` with `new[]` / `delete[]`), file handling, exception handling.

## Folder contents
```
main.cpp                      creates SportsCenter and calls run()
Record.h/.cpp                 abstract base class
Equipment, Member, Allocation, Return (.h/.cpp)   entity classes
Store.h                       template dynamic array
SportsCenter.h/.cpp           system class (menus + transactions)
FileManager.h/.cpp            save / load of the data files
Utils.h/.cpp                  validation, input helpers, exceptions
Data/                         equipment.txt, members.txt, allocations.txt, returns.txt (created automatically)
Makefile                      build script (Linux / macOS / MinGW)
Build_Windows.bat             builds SportsEquipment.exe on Windows (needs g++ / MinGW)
Run_SportsEquipment.bat       runs the program on Windows (builds it first if needed)
SportsEquipment               ready-to-run Linux executable
```

## Build and run
Windows: double-click `Build_Windows.bat` (creates `SportsEquipment.exe`), then `Run_SportsEquipment.bat`.

Linux / macOS / MinGW terminal:
```
make
./SportsEquipment
```
or without make:
```
g++ -std=c++11 main.cpp SportsCenter.cpp FileManager.cpp Record.cpp Equipment.cpp Member.cpp Allocation.cpp Return.cpp Utils.cpp -o SportsEquipment
```
Run the program from the folder that contains `Data/`. To use another data folder: `SportsEquipment path/to/folder`.

## Data file formats (one record per line, fields separated by `|`)
- `equipment.txt`   id|name|type|status
- `members.txt`     id|name|phone
- `allocations.txt` id|equipmentId|memberId|date|returned
- `returns.txt`     id|allocationId|date|condition
