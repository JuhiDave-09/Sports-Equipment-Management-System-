#include "Equipment.h"
#include "Utils.h"
#include <iomanip>
#include <cstdlib>

Equipment::Equipment() : Record(), type(""), status("Available") {}
Equipment::Equipment(int i, const std::string& n, const std::string& t, const std::string& s)
    : Record(i, n), type(t), status(s) {}
Equipment::~Equipment() {}

const std::string& Equipment::getType() const { return type; }
const std::string& Equipment::getStatus() const { return status; }
void Equipment::setType(const std::string& t) { type = t; }
void Equipment::updateStatus(const std::string& s) { status = s; }
bool Equipment::isAvailable() const { return status == "Available"; }

void Equipment::display() const {
    std::cout << "  ID: " << std::setw(3) << id << " | " << std::left << std::setw(22) << name
              << " | " << std::setw(14) << type << " | " << status << std::right << "\n";
}
std::string Equipment::serialize() const {
    return std::to_string(id) + "|" + name + "|" + type + "|" + status;
}
void Equipment::deserialize(const std::string& line) {
    std::string f[4];
    if (splitFields(line, f, 4) != 4) throw AppException("Corrupt equipment record: " + line);
    id = atoi(f[0].c_str());
    name = f[1]; type = f[2]; status = f[3];
    if (id <= 0 || name.empty()) throw AppException("Corrupt equipment record: " + line);
}
std::string Equipment::typeName() const { return "Equipment"; }
