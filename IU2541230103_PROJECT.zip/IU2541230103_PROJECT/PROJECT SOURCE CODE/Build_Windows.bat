@echo off
cd /d "%~dp0"
echo Compiling Sports Equipment Management...
g++ -std=c++11 main.cpp SportsCenter.cpp FileManager.cpp Record.cpp Equipment.cpp Member.cpp Allocation.cpp Return.cpp Utils.cpp -o SportsEquipment.exe
if errorlevel 1 (
    echo.
    echo Build failed. Please install MinGW-w64 g++ ^(or use Code::Blocks / Dev-C++^) and try again.
    pause
    exit /b 1
)
echo.
echo Build successful: SportsEquipment.exe created.
pause
