#ifndef RECORD_H
#define RECORD_H
#include <string>
#include <iostream>

// Abstract base class: every entity has an id and a name and must
// implement the polymorphic interface below.
class Record {
protected:
    int id;
    std::string name;
public:
    Record();
    Record(int id, const std::string& name);
    virtual ~Record();

    int getId() const;
    const std::string& getName() const;
    void setId(int newId);
    void setName(const std::string& newName);

    virtual void display() const = 0;
    virtual std::string serialize() const = 0;
    virtual void deserialize(const std::string& line) = 0;
    virtual std::string typeName() const = 0;
};

// split a '|' separated line into fields
int splitFields(const std::string& line, std::string out[], int maxFields);
#endif
