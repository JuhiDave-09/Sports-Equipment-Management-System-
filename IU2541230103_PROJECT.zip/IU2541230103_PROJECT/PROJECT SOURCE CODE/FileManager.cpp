#include "FileManager.h"
#include "SportsCenter.h"
#include "Utils.h"
#include <fstream>
#include <sys/stat.h>
#ifdef _WIN32
#include <direct.h>
#endif

namespace {
    // Polymorphic save: works on any Store of Record-derived objects through Record*
    template <typename T>
    void saveStore(Store<T>& s, const std::string& file) {
        std::ofstream out(file.c_str());
        if (!out) throw AppException("Cannot write file: " + file);
        for (int i = 0; i < s.size(); i++) {
            Record* r = &s.at(i);              // base-class pointer
            out << r->serialize() << "\n";     // virtual call -> derived version
        }
        if (!out) throw AppException("Error while writing file: " + file);
    }

    template <typename T>
    bool loadStore(Store<T>& s, const std::string& file) {
        std::ifstream in(file.c_str());
        if (!in) return false;                 // missing file = first run
        s.clear();
        std::string line;
        int lineNo = 0;
        while (std::getline(in, line)) {
            lineNo++;
            line = trim(line);
            if (line.empty()) continue;
            T item;
            Record* r = &item;
            try { r->deserialize(line); }
            catch (const AppException& e) {
                throw AppException(file + " (line " + std::to_string(lineNo) + "): " + e.what());
            }
            s.add(item);
        }
        return true;
    }
}

FileManager::FileManager() : dir("Data") {}
FileManager::FileManager(const std::string& d) : dir(d) {}
FileManager::~FileManager() {}

std::string FileManager::path(const std::string& file) const { return dir + "/" + file; }

void FileManager::ensureDir() const {
#ifdef _WIN32
    _mkdir(dir.c_str());
#else
    mkdir(dir.c_str(), 0755);
#endif
}

void FileManager::save(SportsCenter& sc) {
    ensureDir();
    saveStore(sc.equipmentStore(),  path("equipment.txt"));
    saveStore(sc.memberStore(),     path("members.txt"));
    saveStore(sc.allocationStore(), path("allocations.txt"));
    saveStore(sc.returnStore(),     path("returns.txt"));
}

bool FileManager::load(SportsCenter& sc) {
    bool a = loadStore(sc.equipmentStore(),  path("equipment.txt"));
    bool b = loadStore(sc.memberStore(),     path("members.txt"));
    bool c = loadStore(sc.allocationStore(), path("allocations.txt"));
    bool d = loadStore(sc.returnStore(),     path("returns.txt"));
    return a || b || c || d;
}
