#include "SportsCenter.h"
#include "Utils.h"
#include <iostream>

using std::cout;

namespace {
    // Runtime polymorphism: the list is walked through Record* and the
    // correct derived display() is called at run time.
    template <typename T>
    void showAll(Store<T>& s, const std::string& title) {
        cout << "\n--- " << title << " (" << s.size() << ") ---\n";
        if (s.size() == 0) cout << "  (no records)\n";
        for (int i = 0; i < s.size(); i++) {
            Record* r = &s.at(i);
            r->display();
        }
    }
    std::string idStr(int id) { return std::to_string(id); }
}

SportsCenter::SportsCenter(const std::string& dataDir)
    : equipment(4), members(4), allocations(4), returns(4), fm(dataDir), dirty(false), blockAutoSave(false) {}
SportsCenter::~SportsCenter() {}   // Store<T> destructors release the arrays (delete[])

Store<Equipment>& SportsCenter::equipmentStore() { return equipment; }
Store<Member>& SportsCenter::memberStore() { return members; }
Store<Allocation>& SportsCenter::allocationStore() { return allocations; }
Store<Return>& SportsCenter::returnStore() { return returns; }

// ---------------- helpers ----------------
int SportsCenter::activeCountOfMember(int memberId) const {
    int n = 0;
    for (int i = 0; i < allocations.size(); i++)
        if (allocations.at(i).getMemberId() == memberId && !allocations.at(i).isReturned()) n++;
    return n;
}
int SportsCenter::activeAllocationOfEquipment(int equipmentId) const {
    for (int i = 0; i < allocations.size(); i++)
        if (allocations.at(i).getEquipmentId() == equipmentId && !allocations.at(i).isReturned())
            return allocations.at(i).getId();
    return 0;
}
std::string SportsCenter::equipmentName(int id) const {
    int i = equipment.indexOfId(id);
    return i < 0 ? "(deleted)" : equipment.at(i).getName();
}
std::string SportsCenter::memberName(int id) const {
    int i = members.indexOfId(id);
    return i < 0 ? "(deleted)" : members.at(i).getName();
}

// ---------------- core operations ----------------
int SportsCenter::addEquipment(const std::string& name, const std::string& type) {
    validateText(name, "Equipment name");
    validateText(type, "Type");
    for (int i = 0; i < equipment.size(); i++)
        if (toLower(equipment.at(i).getName()) == toLower(name))
            throw AppException("Equipment with this name already exists.");
    int id = equipment.nextId();
    equipment.add(Equipment(id, name, type, "Available"));
    dirty = true;
    return id;
}

int SportsCenter::addMember(const std::string& name, const std::string& phone) {
    validateName(name);
    validatePhone(phone);
    for (int i = 0; i < members.size(); i++)
        if (members.at(i).getPhone() == phone)
            throw AppException("A member with this phone number already exists.");
    int id = members.nextId();
    members.add(Member(id, name, phone));
    dirty = true;
    return id;
}

// MAIN TRANSACTION 1: issue equipment to a member
int SportsCenter::issueEquipment(int equipmentId, int memberId, const std::string& date) {
    validateDate(date);
    int ei = equipment.indexOfId(equipmentId);
    if (ei < 0) throw AppException("Equipment ID not found.");
    int mi = members.indexOfId(memberId);
    if (mi < 0) throw AppException("Member ID not found.");
    Equipment& eq = equipment.at(ei);
    if (!eq.isAvailable())
        throw AppException("Equipment is not available (status: " + eq.getStatus() + ").");
    if (activeCountOfMember(memberId) >= MAX_ITEMS_PER_MEMBER)
        throw AppException("Member already holds the maximum of 3 items.");

    Allocation a;
    a.setId(allocations.nextId());
    a.allocate(equipmentId, memberId, date);
    allocations.add(a);
    eq.updateStatus("Issued");
    dirty = true;
    return a.getId();
}

// MAIN TRANSACTION 2: return an issued item
int SportsCenter::returnEquipment(int allocationId, const std::string& date, const std::string& cond) {
    validateDate(date);
    int ai = allocations.indexOfId(allocationId);
    if (ai < 0) throw AppException("Allocation ID not found.");
    Allocation& a = allocations.at(ai);
    if (a.isReturned()) throw AppException("This allocation has already been returned.");
    if (dateToNumber(date) < dateToNumber(a.getDate()))
        throw AppException("Return date cannot be before the issue date.");
    if (cond != "Good" && cond != "Damaged" && cond != "Lost")
        throw AppException("Condition must be Good, Damaged or Lost.");

    Return r;
    r.setId(returns.nextId());
    r.processReturn(allocationId, date, cond);
    returns.add(r);
    a.setReturned(true);

    int ei = equipment.indexOfId(a.getEquipmentId());
    if (ei >= 0) {
        std::string st = (cond == "Good") ? "Available" : (cond == "Damaged" ? "Under Repair" : "Lost");
        equipment.at(ei).updateStatus(st);
    }
    dirty = true;
    return r.getId();
}

void SportsCenter::deleteEquipment(int id) {
    int i = equipment.indexOfId(id);
    if (i < 0) throw AppException("Equipment ID not found.");
    if (activeAllocationOfEquipment(id) != 0)
        throw AppException("Cannot delete: this equipment is currently issued to a member.");
    // cascade: remove its allocation history and the returns linked to it
    for (int k = allocations.size() - 1; k >= 0; k--) {
        if (allocations.at(k).getEquipmentId() == id) {
            int aid = allocations.at(k).getId();
            for (int r = returns.size() - 1; r >= 0; r--)
                if (returns.at(r).getAllocationId() == aid) returns.removeAt(r);
            allocations.removeAt(k);
        }
    }
    equipment.removeAt(equipment.indexOfId(id));
    dirty = true;
}

void SportsCenter::deleteMember(int id) {
    int i = members.indexOfId(id);
    if (i < 0) throw AppException("Member ID not found.");
    if (activeCountOfMember(id) > 0)
        throw AppException("Cannot delete: this member still holds issued equipment.");
    for (int k = allocations.size() - 1; k >= 0; k--) {
        if (allocations.at(k).getMemberId() == id) {
            int aid = allocations.at(k).getId();
            for (int r = returns.size() - 1; r >= 0; r--)
                if (returns.at(r).getAllocationId() == aid) returns.removeAt(r);
            allocations.removeAt(k);
        }
    }
    members.removeAt(members.indexOfId(id));
    dirty = true;
}

void SportsCenter::report() const {
    int avail = 0, issued = 0, repair = 0, lost = 0;
    for (int i = 0; i < equipment.size(); i++) {
        const std::string& s = equipment.at(i).getStatus();
        if (s == "Available") avail++;
        else if (s == "Issued") issued++;
        else if (s == "Under Repair") repair++;
        else if (s == "Lost") lost++;
    }
    cout << "\n========== SPORTS EQUIPMENT REPORT ==========\n";
    cout << "Total equipment: " << equipment.size() << "\n";
    cout << "  Available: " << avail << " | Issued: " << issued
         << " | Under Repair: " << repair << " | Lost: " << lost << "\n";
    cout << "Total members: " << members.size() << "\n";
    cout << "Total allocations: " << allocations.size() << "\n";
    cout << "Total returns: " << returns.size() << "\n";

    cout << "\nCurrently issued equipment:\n";
    int shown = 0;
    for (int i = 0; i < allocations.size(); i++) {
        const Allocation& a = allocations.at(i);
        if (!a.isReturned()) {
            cout << "  " << equipmentName(a.getEquipmentId()) << " -> " << memberName(a.getMemberId())
                 << " (since " << a.getDate() << ")\n";
            shown++;
        }
    }
    if (shown == 0) cout << "  (none)\n";

    cout << "\nMembers with no equipment currently:\n";
    shown = 0;
    for (int i = 0; i < members.size(); i++)
        if (activeCountOfMember(members.at(i).getId()) == 0) {
            cout << "  " << members.at(i).getName() << "\n";
            shown++;
        }
    if (shown == 0) cout << "  (none)\n";

    int bad = 0;
    for (int i = 0; i < returns.size(); i++)
        if (returns.at(i).getCondition() != "Good") bad++;
    cout << "\nReturns in Damaged/Lost condition: " << bad << "\n";
    cout << "=============================================\n";
}

// ---------------- menu handlers ----------------
void SportsCenter::menuAdd() {
    cout << "\n1. Add Equipment\n2. Add Member\n0. Back\n";
    int c = readInt("Choice: ", 0, 2);
    if (c == 1) {
        std::string n = readText("Equipment name: ", "Equipment name");
        std::string t = readText("Type (e.g. Cricket, Football): ", "Type");
        int id = addEquipment(n, t);
        cout << "Equipment added with ID " << id << ".\n";
    } else if (c == 2) {
        std::string n = readName("Member name: ");
        std::string p = readPhone("Phone (10 digits): ");
        int id = addMember(n, p);
        cout << "Member added with ID " << id << ".\n";
    }
}

void SportsCenter::menuDisplay() {
    cout << "\n1. Equipment\n2. Members\n3. Allocations\n4. Returns\n0. Back\n";
    int c = readInt("Choice: ", 0, 4);
    if (c == 1) showAll(equipment, "Equipment");
    else if (c == 2) showAll(members, "Members");
    else if (c == 3) showAll(allocations, "Allocations");
    else if (c == 4) showAll(returns, "Returns");
}

void SportsCenter::menuSearch() {
    cout << "\n1. Search Equipment\n2. Search Members\n3. Search Allocations\n0. Back\n";
    int c = readInt("Choice: ", 0, 3);
    if (c == 0) return;
    std::string key = readLine("Enter ID or keyword: ");
    if (key.empty()) throw ValidationException("Search keyword cannot be empty.");
    int found = 0;
    if (c == 1) {
        for (int i = 0; i < equipment.size(); i++) {
            const Equipment& e = equipment.at(i);
            if (idStr(e.getId()) == key || containsNoCase(e.getName(), key) ||
                containsNoCase(e.getType(), key) || containsNoCase(e.getStatus(), key)) {
                e.display(); found++;
            }
        }
    } else if (c == 2) {
        for (int i = 0; i < members.size(); i++) {
            const Member& m = members.at(i);
            if (idStr(m.getId()) == key || containsNoCase(m.getName(), key) || containsNoCase(m.getPhone(), key)) {
                m.display(); found++;
            }
        }
    } else {
        for (int i = 0; i < allocations.size(); i++) {
            const Allocation& a = allocations.at(i);
            if (idStr(a.getId()) == key || containsNoCase(a.getDate(), key) ||
                containsNoCase(equipmentName(a.getEquipmentId()), key) ||
                containsNoCase(memberName(a.getMemberId()), key)) {
                a.display(); found++;
            }
        }
    }
    if (found == 0) cout << "No matching record found.\n";
    else cout << found << " record(s) found.\n";
}

void SportsCenter::menuUpdate() {
    cout << "\n1. Update Equipment\n2. Update Member\n0. Back\n";
    int c = readInt("Choice: ", 0, 2);
    if (c == 1) {
        int id = readInt("Equipment ID: ", 1, 999999);
        int i = equipment.indexOfId(id);
        if (i < 0) throw AppException("Equipment ID not found.");
        Equipment& e = equipment.at(i);
        cout << "Current: "; e.display();
        cout << "(press Enter to keep the current value)\n";
        std::string n = readLine("New name: ");
        std::string t = readLine("New type: ");
        if (!n.empty()) {
            validateText(n, "Equipment name");
            for (int k = 0; k < equipment.size(); k++)
                if (k != i && toLower(equipment.at(k).getName()) == toLower(n))
                    throw AppException("Equipment with this name already exists.");
        }
        if (!t.empty()) validateText(t, "Type");
        cout << "New status: 0 = keep, 1 = Available, 2 = Under Repair, 3 = Lost\n";
        int s = readInt("Status choice: ", 0, 3);
        if (s != 0 && e.getStatus() == "Issued")
            throw AppException("Status cannot be changed while the equipment is issued. Process its return first.");
        if (!n.empty()) e.setName(n);
        if (!t.empty()) e.setType(t);
        if (s == 1) e.updateStatus("Available");
        else if (s == 2) e.updateStatus("Under Repair");
        else if (s == 3) e.updateStatus("Lost");
        dirty = true;
        cout << "Record updated.\n";
        e.display();
    } else if (c == 2) {
        int id = readInt("Member ID: ", 1, 999999);
        int i = members.indexOfId(id);
        if (i < 0) throw AppException("Member ID not found.");
        Member& m = members.at(i);
        cout << "Current: "; m.display();
        cout << "(press Enter to keep the current value)\n";
        std::string n = readLine("New name: ");
        std::string p = readLine("New phone: ");
        if (!n.empty()) validateName(n);
        if (!p.empty()) {
            validatePhone(p);
            for (int k = 0; k < members.size(); k++)
                if (k != i && members.at(k).getPhone() == p)
                    throw AppException("A member with this phone number already exists.");
        }
        if (!n.empty()) m.setName(n);
        if (!p.empty()) m.setPhone(p);
        dirty = true;
        cout << "Record updated.\n";
        m.display();
    }
}

void SportsCenter::menuDelete() {
    cout << "\n1. Delete Equipment\n2. Delete Member\n0. Back\n";
    int c = readInt("Choice: ", 0, 2);
    if (c == 1) {
        int id = readInt("Equipment ID: ", 1, 999999);
        deleteEquipment(id);
        cout << "Record deleted.\n";
    } else if (c == 2) {
        int id = readInt("Member ID: ", 1, 999999);
        deleteMember(id);
        cout << "Record deleted.\n";
    }
}

void SportsCenter::menuTransaction() {
    cout << "\n1. Issue Equipment to Member\n2. Return Equipment\n0. Back\n";
    int c = readInt("Choice: ", 0, 2);
    if (c == 1) {
        int e = readInt("Equipment ID: ", 1, 999999);
        int m = readInt("Member ID: ", 1, 999999);
        std::string d = readDate("Issue date (DD/MM/YYYY): ");
        int id = issueEquipment(e, m, d);
        cout << "Equipment issued successfully. Allocation ID: " << id << ".\n";
    } else if (c == 2) {
        int a = readInt("Allocation ID: ", 1, 999999);
        std::string d = readDate("Return date (DD/MM/YYYY): ");
        cout << "Condition: 1 = Good, 2 = Damaged, 3 = Lost\n";
        int k = readInt("Condition choice: ", 1, 3);
        std::string cond = (k == 1) ? "Good" : (k == 2 ? "Damaged" : "Lost");
        int id = returnEquipment(a, d, cond);
        cout << "Equipment returned successfully. Return ID: " << id << ". Condition: " << cond << ".\n";
    }
}

void SportsCenter::menuSaveLoad() {
    cout << "\n1. Save data\n2. Load data\n0. Back\n";
    int c = readInt("Choice: ", 0, 2);
    if (c == 1) { saveAll(); }
    else if (c == 2) { loadAll(); }
}

void SportsCenter::saveAll() {
    fm.save(*this);
    dirty = false;
    blockAutoSave = false;
    cout << "Data saved.\n";
}
void SportsCenter::loadAll() {
    try {
        bool found = fm.load(*this);
        dirty = false;
        if (found) cout << "Existing records loaded: " << equipment.size() << " equipment, "
                        << members.size() << " members, " << allocations.size() << " allocations, "
                        << returns.size() << " returns.\n";
        else cout << "No saved data found. Starting with empty records.\n";
    } catch (const AppException&) {
        equipment.clear(); members.clear(); allocations.clear(); returns.clear();
        throw;
    }
}

void SportsCenter::run() {
    cout << "====================================================\n";
    cout << "        SPORTS EQUIPMENT MANAGEMENT SYSTEM\n";
    cout << "====================================================\n";
    try { loadAll(); }
    catch (const AppException& e) {
        cout << "Error loading data: " << e.what() << "\n";
        blockAutoSave = true;   // protect the damaged files from being overwritten on exit
    }

    bool running = true;
    while (running) {
        try {
            cout << "\n========== MAIN MENU ==========\n"
                 << "1. Add Record\n2. Display Records\n3. Search Record\n4. Update Record\n"
                 << "5. Delete Record\n6. Main Transaction (Issue / Return)\n7. Report\n"
                 << "8. Save / Load\n9. Exit\n";
            int c = readInt("Enter choice: ", 1, 9);
            switch (c) {
                case 1: menuAdd(); break;
                case 2: menuDisplay(); break;
                case 3: menuSearch(); break;
                case 4: menuUpdate(); break;
                case 5: menuDelete(); break;
                case 6: menuTransaction(); break;
                case 7: report(); break;
                case 8: menuSaveLoad(); break;
                case 9: running = false; break;
            }
        }
        catch (const InputClosedException&) { running = false; }
        catch (const AppException& e) { cout << "Error: " << e.what() << "\n"; }
        catch (const std::exception& e) { cout << "Unexpected error: " << e.what() << "\n"; }
    }
    try {
        if (blockAutoSave) cout << "Data files were not overwritten because they could not be loaded. "
                                   "Fix them, or use Save (option 8) to overwrite.\n";
        else saveAll();
    }
    catch (const AppException& e) { cout << "Error saving data: " << e.what() << "\n"; }
    cout << "Thank you. Goodbye!\n";
}
