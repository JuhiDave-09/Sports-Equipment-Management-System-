#include "Allocation.h"
#include "Utils.h"
#include <iomanip>
#include <cstdlib>

Allocation::Allocation() : Record(), equipmentId(0), memberId(0), date(""), returned(false) {}
Allocation::Allocation(int i, int e, int m, const std::string& d)
    : Record(i, "Allocation"), equipmentId(e), memberId(m), date(d), returned(false) {}
Allocation::~Allocation() {}

void Allocation::allocate(int eqId, int memId, const std::string& d) {
    equipmentId = eqId; memberId = memId; date = d; returned = false;
    name = "Allocation";
}
int Allocation::getEquipmentId() const { return equipmentId; }
int Allocation::getMemberId() const { return memberId; }
const std::string& Allocation::getDate() const { return date; }
bool Allocation::isReturned() const { return returned; }
void Allocation::setReturned(bool r) { returned = r; }

void Allocation::display() const {
    std::cout << "  Allocation " << std::setw(3) << id << " | Equipment ID: " << std::setw(3) << equipmentId
              << " | Member ID: " << std::setw(3) << memberId << " | Issued: " << date
              << " | " << (returned ? "Returned" : "With member") << "\n";
}
std::string Allocation::serialize() const {
    return std::to_string(id) + "|" + std::to_string(equipmentId) + "|" + std::to_string(memberId) +
           "|" + date + "|" + (returned ? "1" : "0");
}
void Allocation::deserialize(const std::string& line) {
    std::string f[5];
    if (splitFields(line, f, 5) != 5) throw AppException("Corrupt allocation record: " + line);
    id = atoi(f[0].c_str());
    equipmentId = atoi(f[1].c_str());
    memberId = atoi(f[2].c_str());
    date = f[3];
    returned = (f[4] == "1");
    name = "Allocation";
    if (id <= 0 || equipmentId <= 0 || memberId <= 0) throw AppException("Corrupt allocation record: " + line);
    validateDate(date);
}
std::string Allocation::typeName() const { return "Allocation"; }
