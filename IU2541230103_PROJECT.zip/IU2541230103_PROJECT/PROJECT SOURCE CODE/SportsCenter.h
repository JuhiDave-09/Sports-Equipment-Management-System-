#ifndef SPORTSCENTER_H
#define SPORTSCENTER_H
#include <string>
#include "Store.h"
#include "Equipment.h"
#include "Member.h"
#include "Allocation.h"
#include "Return.h"
#include "FileManager.h"

// System class: owns all data, implements every menu option and the main transaction
class SportsCenter {
private:
    Store<Equipment> equipment;
    Store<Member> members;
    Store<Allocation> allocations;
    Store<Return> returns;
    FileManager fm;
    bool dirty;                       // unsaved changes exist
    bool blockAutoSave;               // true if data files could not be loaded (do not overwrite them)

    static const int MAX_ITEMS_PER_MEMBER = 3;

    int activeCountOfMember(int memberId) const;
    int activeAllocationOfEquipment(int equipmentId) const;
    std::string equipmentName(int id) const;
    std::string memberName(int id) const;

    // menu handlers
    void menuAdd();
    void menuDisplay();
    void menuSearch();
    void menuUpdate();
    void menuDelete();
    void menuTransaction();
    void menuSaveLoad();

public:
    explicit SportsCenter(const std::string& dataDir = "Data");
    ~SportsCenter();

    // core operations
    int addEquipment(const std::string& name, const std::string& type);
    int addMember(const std::string& name, const std::string& phone);
    int issueEquipment(int equipmentId, int memberId, const std::string& date);              // main transaction 1
    int returnEquipment(int allocationId, const std::string& date, const std::string& cond); // main transaction 2
    void deleteEquipment(int id);
    void deleteMember(int id);
    void report() const;

    void saveAll();
    void loadAll();
    void run();

    // access for FileManager
    Store<Equipment>& equipmentStore();
    Store<Member>& memberStore();
    Store<Allocation>& allocationStore();
    Store<Return>& returnStore();
};
#endif
